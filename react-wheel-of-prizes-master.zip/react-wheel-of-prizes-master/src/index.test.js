import { WheelComponent } from '.'

describe('WheelComponent', () => {
  it('is truthy', () => {
    expect(WheelComponent).toBeTruthy()
  })
})
